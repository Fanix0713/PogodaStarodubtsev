//
//  ViewController.swift
//  Pogoda_Starodubtsev
//
//  Created by user on 05.10.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

